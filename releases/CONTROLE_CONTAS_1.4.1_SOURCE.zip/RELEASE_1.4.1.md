# Controle de Contas 1.4.1

- Aprendizado de layouts V2 isolado por estrutura.
- Todo PDF confirmado pode reforçar o layout sem alterar outros perfis.
- Preserva o aprendizado V1 como compatibilidade.
- Mantém Cloudflare/mobile sem alteração em `cloud_sync.py` e `cloud_mobile_ui.py`.
- Atualizador encerra o processo de sincronização antes de substituir DLLs do aplicativo.
- Ícone do aplicativo e instalador preservado.

from __future__ import annotations

import os
from pathlib import Path

_ui_integrated = False


def cleanup_legacy_mobile_autostart() -> None:
    """Remove apenas o autostart antigo do servidor/túnel local, não dados do usuário."""
    if os.name != "nt":
        return

    try:
        import winreg

        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE,
        ) as key:
            try:
                winreg.DeleteValue(key, "ControleContasMobile")
            except FileNotFoundError:
                pass
    except Exception:
        pass


def integrate_cloud_mobile_button() -> None:
    global _ui_integrated
    if _ui_integrated:
        return

    from . import ui
    from .cloud_sync import cloud_enabled, get_cloud_private_link

    original_init = ui.JanelaPrincipal.__init__

    def init_with_cloud_mobile(self, *args, **kwargs):
        original_init(self, *args, **kwargs)

        try:
            header = self.findChild(ui.QFrame, "headerPanel")
            layout = header.layout() if header else None
            if layout is None:
                return

            button = ui.QPushButton("📱  Acesso mobile")
            button.setObjectName("secondaryButton")
            button.setToolTip(
                "Copia o link privativo do painel mobile em nuvem."
            )

            def show_mobile_access():
                if not cloud_enabled():
                    ui.QMessageBox.warning(
                        self,
                        "Acesso mobile",
                        "A sincronização em nuvem ainda não está configurada neste computador.",
                    )
                    return

                link = get_cloud_private_link()
                if not link:
                    ui.QMessageBox.warning(
                        self,
                        "Acesso mobile",
                        "Não foi possível localizar o link privativo do mobile.",
                    )
                    return

                ui.QApplication.clipboard().setText(link)
                ui.QMessageBox.information(
                    self,
                    "Acesso mobile",
                    "O link privativo foi copiado para a área de transferência.\n\n"
                    "O mobile usa a última versão sincronizada na nuvem e continua "
                    "disponível mesmo quando este computador estiver desligado.\n\n"
                    "Não compartilhe o link publicamente.",
                )

            button.clicked.connect(show_mobile_access)

            new_account_index = -1
            for i in range(layout.count()):
                item = layout.itemAt(i)
                widget = item.widget() if item else None
                if isinstance(widget, ui.QPushButton) and "Nova conta" in widget.text():
                    new_account_index = i
                    break

            if new_account_index >= 0:
                layout.insertWidget(new_account_index, button)
            else:
                layout.addWidget(button)

            self._cloud_mobile_button = button
        except Exception:
            pass

    ui.JanelaPrincipal.__init__ = init_with_cloud_mobile
    _ui_integrated = True

# Controle de Contas 1.4.2

Hotfix do leitor de documentos tributários e proteção do Aprendizado V2.

- DARF de pessoa física agora reconhece CPF + nome do contribuinte diretamente.
- Impede que palavras de interface/frase como `este`, `até`, `documento` e similares sejam aprendidas como Pagador/Recebedor.
- Perfis V2 já contaminados deixam de aplicar esses valores inválidos automaticamente.
- Mantém os perfis bons existentes; não apaga o aprendizado V1/V2.
- Cloudflare/mobile permanece inalterado.

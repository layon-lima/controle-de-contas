# Controle de Contas 1.4.4

Correção da causa real da regressão em DARF/ITR escaneado.

- Reproduzido o erro exato usando OCR somente ENG: Recebedor vazio, Pagador "até", Valor 0 e vencimento vazio.
- Reconhecimento de DARF agora tolera erros típicos do OCR ENG (arrecadagao/apuragao/composigao).
- Tesseract empacotado passa a ter prioridade sobre instalações do Windows no PATH.
- Build inclui `por.traineddata` para OCR em português.
- Mesmo sem POR, o parser estrutural continua reconhecendo o IMPOSTO.pdf corretamente.
- Mobile/Cloudflare não foi alterado.
